from query import cli
import sys
cli(sys.argv[1:])
